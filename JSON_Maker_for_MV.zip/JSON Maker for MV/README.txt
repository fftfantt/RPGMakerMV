﻿■このソフトについて

RPGツクールMVプロジェクトファイルの素材一覧が記載されたJSONを生成します。


■使い方

「対象プロジェクト」と「書き出し先」を設定して「JSON書出」ボタンを押します。
必要に応じて書き出すファイルの種類や拡張子をつけるなど設定してください。


■必須／推奨環境

Windows7以降のOSでご利用いただけます。(Windows7とWindows10で動作確認)
そのままの環境でも動く可能性が高いですが、.NET Framework 3.5がインストールされていることが望ましいです。

Windows 8、Windows 8.1、および Windows 10 への .NET Framework 3.5 のインストール
https://msdn.microsoft.com/ja-jp/library/hh506443(v=vs.110).aspx

   1. キーボードの Windows キー (Windows のロゴ) を押し、「Windows の機能」と入力して、Enter キーを押します。 
      [Windows の機能の有効化または無効化] ダイアログ ボックスが表示されます。 
      あるいは、[コントロール パネル] を開き、[プログラム] の項目をクリックし、[プログラムと機能] で 
      [Windows の機能の有効化または無効化] をクリックします。

   2. .NET Framework 3.5 (.NET 2.0 および 3.0 を含む) チェック ボックスをオンにして [OK] をクリックし、
      メッセージが表示された場合はコンピューターを再起動します。


■利用規約


当プログラムはMITライセンスのもとで公開されています。
https://osdn.jp/projects/opensource/wiki/licenses%2FMIT_license
 

・商用利用や改変なども自由です。
 
・クレジットも不要です。
 
・ヘッダーのライセンス表記のみ残してください。
 
・当プログラムの不具合およびそれに伴う損害の責任についても、MITライセンスの表記どおりです。

Copyright (c) 2016 fftfantt

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
